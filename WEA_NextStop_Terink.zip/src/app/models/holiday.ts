export type Holiday = {
  id: number;
  startDate: Date;
  endDate: Date;
  name: string;
  isSchoolHoliday: boolean;
};
