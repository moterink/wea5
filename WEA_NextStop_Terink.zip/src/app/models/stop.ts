export type Stop = {
  id: number;
  name: string;
  shortName: string;
  latitude: number;
  longitude: number;
};
