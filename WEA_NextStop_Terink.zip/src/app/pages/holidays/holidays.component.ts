import { Component, inject, model } from "@angular/core";
import {
  DateRange,
  DefaultMatCalendarRangeStrategy,
  MAT_DATE_RANGE_SELECTION_STRATEGY,
  MatCalendarCellClassFunction,
  MatDatepickerModule,
} from "@angular/material/datepicker";
import { MatCardModule } from "@angular/material/card";
import { MatIconModule } from "@angular/material/icon";
import { MatButtonModule } from "@angular/material/button";
import {
  MAT_DIALOG_DATA,
  MatDialog,
  MatDialogActions,
  MatDialogContent,
  MatDialogRef,
  MatDialogTitle,
} from "@angular/material/dialog";
import { Holiday } from "../../models/holiday";
import { HolidayFormComponent } from "./components/holiday-form/holiday-form.component";

@Component({
  selector: "app-holidays",
  imports: [MatCardModule, MatDatepickerModule, MatIconModule, MatButtonModule],
  providers: [
    {
      provide: MAT_DATE_RANGE_SELECTION_STRATEGY,
      useClass: DefaultMatCalendarRangeStrategy,
    },
  ],
  templateUrl: "./holidays.component.html",
  styleUrl: "./holidays.component.css",
})
export class HolidaysComponent {
  readonly dialog = inject(MatDialog);

  dateClass: MatCalendarCellClassFunction<Date> = (cellDate, view) => {
    // Only highligh dates inside the month view.
    if (view === "month") {
      const date = cellDate.getDate();

      // Highlight the 1st and 20th day of each month.
      return date === 1 || date === 20 ? "example-custom-date-class" : "";
    }

    return "";
  };

  selectedDateRange: DateRange<Date> = new DateRange(new Date(), null);

  _onSelectedChange(date: Date | null): void {
    if (
      date &&
      this.selectedDateRange &&
      this.selectedDateRange.start &&
      date > this.selectedDateRange.start &&
      !this.selectedDateRange.end
    ) {
      this.selectedDateRange = new DateRange(
        this.selectedDateRange.start,
        date,
      );
    } else {
      this.selectedDateRange = new DateRange(date, null);
    }
  }

  openCreateDialog(): void {
    const dialogRef = this.dialog.open(CreateHolidayDialog, {
      data: {},
    });

    dialogRef.afterClosed().subscribe((result) => {
      console.log("The dialog was closed", result);
    });
  }
}

@Component({
  selector: "app-create-holiday-dialog",
  template: `
    <h2 mat-dialog-title>Create holiday</h2>
    <mat-dialog-content>
      <app-holiday-form></app-holiday-form>
    </mat-dialog-content>
    <mat-dialog-actions>
      <button mat-button (click)="onCloseClick()">Close</button>
      <button mat-button cdkFocusInitial [disabled]="">Submit</button>
    </mat-dialog-actions>
  `,
  imports: [
    HolidayFormComponent,
    MatButtonModule,
    MatDialogTitle,
    MatDialogContent,
    MatDialogActions,
  ],
})
class CreateHolidayDialog {
  readonly dialogRef = inject(MatDialogRef<CreateHolidayDialog>);
  readonly data = inject<Holiday>(MAT_DIALOG_DATA);

  onCloseClick(): void {
    this.dialogRef.close();
  }
}
