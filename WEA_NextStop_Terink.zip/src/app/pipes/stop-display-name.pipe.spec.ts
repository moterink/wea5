import { StopDisplayNamePipe } from './stop-display-name.pipe';

describe('StopDisplayNamePipe', () => {
  it('create an instance', () => {
    const pipe = new StopDisplayNamePipe();
    expect(pipe).toBeTruthy();
  });
});
