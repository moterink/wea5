export const API_URL = "https://localhost:7084/api";
